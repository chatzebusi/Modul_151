<?php 

/**
     * @OA\Info(title="My First API", version="1")
 */

use Psr\Http\Message\ResponseInterface as Response; 
use Psr\Http\Message\ServerRequestInterface as Request;

use Slim\Factory\AppFactory;

use ReallySimpleJWT\Token;

require __DIR__ . "/../vendor/autoload.php";

require_once('./server/model/Table.php');

header("Content-Type: application/json");

$app = AppFactory::create();

  /**
     * @OA\Get(
     *     path="/API/Get/Product/{parameter}",
     *     summary="Get a product by product_id",
     *     tags={"Get Product"},
     *     @OA\Parameter(
     *         name="product_id",
     *         in="path",
     *         required=true,
     *         description="Identifier from Product",
     *         @OA\Schema(
     *             type="Integer",
     *             example="3"
     *         )
     *     ),
     *     @OA\Response(response="200", description="Successful Product selected"))
     *     v@OA\Response(response="401", description="Unauthorized (need Authentication: /API/Authenticate)"))
     *     v@OA\Response(response="500", description="Server Error (Query statement error)"))
  */
  $app->get("/API/Get/Product/{parameter}", function (Request $request, Response $response, $args) {

    // check if user is authenticated
    if (isset($_COOKIE["token"]) && Token::validate($_COOKIE["token"], "sec!ReT423*&")) {
      $productId  = $args["parameter"];
  
      // set table product
      $tableProduct = new Table();
      $tableProduct->tableName = "product";
  
      // select specific product by product_id
      $result = $tableProduct->select($productId);
  
      // iterate over result and set output accordingly into response body
      while ($row = $result->fetch(PDO::FETCH_ASSOC))
      {
        $response->getBody()->write("sku: " . $row["sku"] . ", active: " . $row["active"] . ", id_category: " . $row["id_category"] . ", name: " . $row["name"] . ", image: " . $row["image"] . ", description: " . $row["description"] . ", price: " . $row["price"] . ", stock: " . $row["stock"]);
        http_response_code(200); 
      }

    } else {

      // error message for unauthorized user
      $response->getBody()->write("token not valid");
      http_response_code(401); 
    }
  
    return $response;
  });

  /**
     * @OA\Post(
     *     path="/API/Authenticate",
     *     summary="Response authentication token on verify",
     *     tags={"authenticate"},
     *     requestBody=@OA\RequestBody(
     *         request="/API/Authenticate",
     *         required=true,
     *         description="userId and password",
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(property="userId", type="string", example="HansPeter123"),
     *                 @OA\Property(property="password", type="string", example="aPassword"),
     *             )
     *         )
     *     ),
     *     @OA\Response(response="200", description="Erklärung der Antwort mit Status 200"))
     * )
  */
  $app->post("/API/Authenticate", function (Request $request, Response $response, $args) {

    // get body request
    $body = file_get_contents('php://input');
  
    // decode it
    $data = json_decode($body, true);
  
    // get authenticated userId and password from file to authenticate user
    $requestBody = file_get_contents("./authUsers.json");
    $requestData = json_decode($requestBody, true);
  
    // if user is authenticate create jwt token
    if ($requestData["userId"] == $data["userId"] && $requestData["password"] == $data["password"]) {
  
      // set attributes for Token::create
      $userId = $requestData["userId"];
      $secret = "sec!ReT423*&";
      $expiration = time() + 3600;
      $issuer     = "localhost";
  
      // create token
      $token = Token::create($userId, $secret, $expiration, $issuer);
  
      // set token into cookies
      setcookie("token", $token, $expiration);
  
      // set response successful message
      $response->getBody()->write("token successful created");
  
      http_response_code(201);
    } else {
  
      // return not authenticate error code
      http_response_code(401);
    }
  
    // return response
    return $response;
  });

  /**
     * @OA\Put(
     *     path="/API/Create/Product/{parameter}",
     *     summary="Create new Product",
     *     tags={"Create product"},
     *     @OA\Parameter(
     *         name="sku",
     *         in="path",
     *         required=true,
     *         description="Article number",
     *         @OA\Schema(
     *             type="string",
     *             example="421bad45"
     *         )
     *     ),
     *     @OA\Parameter(
     *         name="active",
     *         in="path",
     *         required=true,
     *         description="Set if article is available",
     *         @OA\Schema(
     *             type="Boolean",
     *             example="true"
     *         )
     *     ),
     *     @OA\Parameter(
     *         name="id_category",
     *         in="path",
     *         required=false,
     *         description="Set category of the product",
     *         @OA\Schema(
     *             type="Int",
     *             example="321"
     *         )
     *     ),
     *     @OA\Parameter(
     *         name="name",
     *         in="path",
     *         required=true,
     *         description="Set name of the product",
     *         @OA\Schema(
     *             type="String",
     *             example="Schoggi"
     *         )
     *     ),
     *     @OA\Parameter(
     *         name="image",
     *         in="path",
     *         required=true,
     *         description="Set image of the product",
     *         @OA\Schema(
     *             type="String",
     *             example="base64"
     *         )
     *     ),
     *     @OA\Parameter(
     *         name="descriptions",
     *         in="path",
     *         required=true,
     *         description="Description of product",
     *         @OA\Schema(
     *             type="String",
     *             example="This is a product"
     *         )
     *     ),
     *     @OA\Parameter(
     *         name="price",
     *         in="path",
     *         required=true,
     *         description="Price of product",
     *         @OA\Schema(
     *             type="Decimal",
     *             example="32.95"
     *         )
     *     ),
     *     @OA\Parameter(
     *         name="stock",
     *         in="path",
     *         required=true,
     *         description="Numbers of product in stock",
     *         @OA\Schema(
     *             type="Integer",
     *             example="10"
     *         )
     *     ),
     *     requestBody=@OA\RequestBody(
     *         request="/API/Create/Product/{parameter}",
     *         required=false,
     *         description="Nothing",
     *     ),
     *     @OA\Response(response="201", description="Product created"))
     *     v@OA\Response(response="401", description="Unauthorized (need Authentication: /API/Authenticate)"))
     *     v@OA\Response(response="500", description="Server Error (Query statement error)"))
     * )
  */
  $app->put("/API/Create/Product/{parameter}", function (Request $request, Response $response, $args) {

    // check if user is authenticated
    if (isset($_COOKIE["token"]) && Token::validate($_COOKIE["token"], "sec!ReT423*&")) {

      // get params from link
      $params       = $args["parameter"];
  
      // split params by &
      $pieces = explode("&", $params);
  
      $products   = [];
      $isCategorySet = true;
  
      // set all values from params into array and check if id_category is send
      foreach($pieces as $key => $value) { 

        // split value by = to get value and column name separates
        $piece = explode("=", $value);
  
        // if value set push value into array
        if (isset($piece[1])) {
          array_push($products, $piece[1]);
  
          // check if category_id value is set
        } else if ($piece[0] == "id_category" && !isset($piece[1])) {
          $isCategorySet = false;
        }
    }
      
      // set table product
      $tableProduct = new Table();
      $tableProduct->tableName = "product";
  
      // insert product into database
      $result = $tableProduct->insertIntoProduct($products, $isCategorySet);
  
      http_response_code(201);
    } else {

      // error message for unauthorized user
      $response->getBody()->write("token not valid");
      http_response_code(401); 
    }
  
    return $response;
  });
  
  /**
     * @OA\Put(
     *     path="/API/Update/Product/{parameter}",
     *     summary="Update Product",
     *     tags={"Update product"},
     *     @OA\Parameter(
     *         name="sku",
     *         in="path",
     *         required=false,
     *         description="Article number",
     *         @OA\Schema(
     *             type="string",
     *             example="421bad45"
     *         )
     *     ),
     *     @OA\Parameter(
     *         name="active",
     *         in="path",
     *         required=false,
     *         description="Set if article is available",
     *         @OA\Schema(
     *             type="Integer",
     *             example="1"
     *         )
     *     ),
     *     @OA\Parameter(
     *         name="id_category",
     *         in="path",
     *         required=false,
     *         description="Set category of the product",
     *         @OA\Schema(
     *             type="Int",
     *             example="321"
     *         )
     *     ),
     *     @OA\Parameter(
     *         name="name",
     *         in="path",
     *         required=false,
     *         description="Set name of the product",
     *         @OA\Schema(
     *             type="String",
     *             example="Schoggi"
     *         )
     *     ),
     *     @OA\Parameter(
     *         name="image",
     *         in="path",
     *         required=false,
     *         description="Set image of the product",
     *         @OA\Schema(
     *             type="String",
     *             example="base64"
     *         )
     *     ),
     *     @OA\Parameter(
     *         name="descriptions",
     *         in="path",
     *         required=false,
     *         description="Description of product",
     *         @OA\Schema(
     *             type="String",
     *             example="This is a product"
     *         )
     *     ),
     *     @OA\Parameter(
     *         name="price",
     *         in="path",
     *         required=false,
     *         description="Price of product",
     *         @OA\Schema(
     *             type="Decimal",
     *             example="32.95"
     *         )
     *     ),
     *     @OA\Parameter(
     *         name="stock",
     *         in="path",
     *         required=false,
     *         description="Numbers of product in stock",
     *         @OA\Schema(
     *             type="Integer",
     *             example="10"
     *         )
     *     ),
     *     @OA\Parameter(
     *         name="product_id",
     *         in="path",
     *         required=true,
     *         description="Product identifier",
     *         @OA\Schema(
     *             type="Integer",
     *             example="10"
     *         )
     *     ),
     *     requestBody=@OA\RequestBody(
     *         request="/API/Update/Product/{parameter}",
     *         required=false,
     *         description="Nothing",
     *     ),
     *     @OA\Response(response="201", description="Product update"))
     *     v@OA\Response(response="401", description="Unauthorized (need Authentication: /API/Authenticate)"))
     *     v@OA\Response(response="418", description="Missing parameter (need product_id: /API/Update/Product)"))
     *     v@OA\Response(response="500", description="Server Error (Query statement error)"))
     * )
  */
  $app->put("/API/Update/Product/{parameter}", function (Request $request, Response $response, $args) {

    // check if user is authenticated
    if (isset($_COOKIE["token"]) && Token::validate($_COOKIE["token"], "sec!ReT423*&")) {

      // get params from link
      $params       = $args["parameter"];
  
      // split params by &
      $pieces = explode("&", $params);
  
      $products   = [];
      $sql = [];
      $productId = 0;
      $isProductId = false;
  
      // structure parameters from request
      foreach($pieces as $key => $value) { 

        // split params by =
        $piece = explode("=", $value);
  
        // check if value from column is set
        if (isset($piece[1])) {

          // check if column not product_id
          if ($piece[0] !== "product_id") {

            // set column into a array
            $sql[] = " $piece[0] = ?";
  
            // set values from columns into another array
            array_push($products, $piece[1]);
          } else {

            // if column product_id have value get value from it and set boolean to true
            if (isset($piece[1])) {
              $isProductId = true;
              $productId = $piece[1];
            }
          }
        }
      }
  
      // check if product_id is set
      if ($isProductId === false) {

        // return error message if product_id is not set
        $response->getBody()->write("product_id is required");

        // send i'm a Teapot for fun ;)
        http_response_code(418); 
        return $response;
      }
  
      // set table product
      $tableProduct = new Table();
      $tableProduct->tableName = "product";
  
      // insert product into database
      $result = $tableProduct->updateProduct($products, $sql, $productId);
  
      http_response_code(201);
    } else {

      // error message for unauthorized user
      $response->getBody()->write("token not valid");
      http_response_code(401); 
    }

    // add successful message
    $response->getBody()->write("Product successful updated");
    return $response;
  });

  /**
     * @OA\Delete(
     *     path="/API/Delete/Product/{parameter}",
     *     summary="Delete a specific product",
     *     tags={"Delete Product"},
     *     @OA\Parameter(
     *         name="product_id",
     *         in="path",
     *         required=true,
     *         description="Primary key from product",
     *         @OA\Schema(
     *             type="Integer",
     *             example="41"
     *         )
     *     ),
     *     @OA\Response(response="200", description="Successful Product deleted"))
     *     v@OA\Response(response="401", description="Unauthorized (need Authentication: /API/Authenticate)"))
     *     v@OA\Response(response="500", description="Server Error (Query statement error)"))
     * )
  */
  $app->delete("/API/Delete/Product/{parameter}", function (Request $request, Response $response, $args) { 

    // check if user is authenticated
    if (isset($_COOKIE["token"]) && Token::validate($_COOKIE["token"], "sec!ReT423*&")) {

      // get param from link
      $productId       = $args["parameter"];

      // set table product
      $tableProduct = new Table();
      $tableProduct->tableName = "product";

      // insert product into database
      $result = $tableProduct->deleteProduct($productId);
      http_response_code(201);
    } else {

      // error message for unauthorized user
      $response->getBody()->write("token not valid");
      http_response_code(401); 
    }

    // set successful message
    $response->getBody()->write("Product successful deleted");
    return $response; 
  });

  /**
     * @OA\Get(
     *     path="/API/Get/All/Product",
     *     summary="Get all Products from Database",
     *     tags={"Get Products"},
     *     @OA\Response(response="200", description="Successful Product selected"))
     *     v@OA\Response(response="401", description="Unauthorized (need Authentication: /API/Authenticate)"))
     *     v@OA\Response(response="500", description="Server Error (Query statement error)"))
  */
  $app->get("/API/Get/All/Product", function (Request $request, Response $response, $args) {

    // check if user is authenticated
    if (isset($_COOKIE["token"]) && Token::validate($_COOKIE["token"], "sec!ReT423*&")) {

      // set table product
      $tableProduct = new Table();
      $tableProduct->tableName = "product";
  
      // select specific product by product_id
      $result = $tableProduct->selectAll();

      // iterate over result and set output accordingly into response body
      while ($row = $result->fetch(PDO::FETCH_ASSOC))
      {
        $response->getBody()->write("sku: " . $row["sku"] . ", active: " . $row["active"] . ", id_category: " . $row["id_category"] . ", name: " . $row["name"] . ", image: " . $row["image"] . ", description: " . $row["description"] . ", price: " . $row["price"] . ", stock: " . $row["stock"]);
        http_response_code(200); 
      }
    } else {

      // error message for unauthorized user
      $response->getBody()->write("token not valid");
      http_response_code(401); 
    }
    
    return $response;
  });

  /**
     * @OA\Put(
     *     path="/API/Create/Category/{parameter}",
     *     summary="Create new Category",
     *     tags={"Create Category"},
     *     @OA\Parameter(
     *         name="active",
     *         in="path",
     *         required=true,
     *         description="Is Category active",
     *         @OA\Schema(
     *             type="Integer",
     *             example="1"
     *         )
     *     ),
     *     @OA\Parameter(
     *         name="name",
     *         in="path",
     *         required=true,
     *         description="Set name of the category",
     *         @OA\Schema(
     *             type="String",
     *             example="Schoggi"
     *         )
     *     ),
     *     requestBody=@OA\RequestBody(
     *         request="/API/Create/Category/{parameter}",
     *         required=false,
     *         description="Nothing",
     *     ),
     *     @OA\Response(response="201", description="Category created"))
     *     v@OA\Response(response="401", description="Unauthorized (need Authentication: /API/Authenticate)"))
     *     v@OA\Response(response="500", description="Server Error (Query statement error)"))
     * )
  */
  $app->put("/API/Create/Category/{parameter}", function (Request $request, Response $response, $args) {

    // check if user is authenticated
    if (isset($_COOKIE["token"]) && Token::validate($_COOKIE["token"], "sec!ReT423*&")) {

      // get params from link
      $params       = $args["parameter"];
  
      // split params by &
      $pieces = explode("&", $params);
  
      $products   = [];
  
      // set all values from params into array
      foreach($pieces as $key => $value) {

        // split by =
        $piece = explode("=", $value);

        // check if values is set
          if (isset($piece[1])) {

            // set values into array
            array_push($products, $piece[1]);
          }
      }
      
      // set table product
      $tableProduct = new Table();
      $tableProduct->tableName = "category";
  
      // insert product into database
      $result = $tableProduct->insertIntoCategory($products);
  
      http_response_code(201);
    } else {

      // error message for unauthorized user
      $response->getBody()->write("token not valid");
      http_response_code(401); 
    }

    return $response;
  });

  /**
     * @OA\Get(
     *     path="/API/Get/Category/{parameter}",
     *     summary="Get a category by category_id",
     *     tags={"Get Category"},
     *     @OA\Parameter(
     *         name="category_id",
     *         in="path",
     *         required=true,
     *         description="Identifier from Category",
     *         @OA\Schema(
     *             type="Integer",
     *             example="41"
     *         )
     *     ),
     *     @OA\Response(response="200", description="Successful Category selected"))
     *     v@OA\Response(response="401", description="Unauthorized (need Authentication: /API/Authenticate)"))
     *     v@OA\Response(response="500", description="Server Error (Query statement error)"))
  */
  $app->get("/API/Get/Category/{parameter}", function (Request $request, Response $response, $args) {

    // check if user is authenticated
    if (isset($_COOKIE["token"]) && Token::validate($_COOKIE["token"], "sec!ReT423*&")) {

    // get category_id from parameter
    $categoryId  = $args["parameter"];

    // set table product
    $tableProduct = new Table();
    $tableProduct->tableName = "category";

    // select specific product by product_id
    $result = $tableProduct->select($categoryId);

    // iterate over result and set output accordingly into response body
    while ($row = $result->fetch(PDO::FETCH_ASSOC))
    {
      echo "active: " . $row["active"] . ", name: " . $row["name"] . " ";
      http_response_code(200); 
    }
    } else {

      // error message for unauthorized user
      $response->getBody()->write("token not valid");
      http_response_code(401); 
    }
  
  return $response;
  });

  /**
     * @OA\Put(
     *     path="/API/Update/Category/{parameter}",
     *     summary="Update Category",
     *     tags={"Update category"},
     *     @OA\Parameter(
     *         name="active",
     *         in="path",
     *         required=false,
     *         description="Set if article is available",
     *         @OA\Schema(
     *             type="Integer",
     *             example="1"
     *         )
     *     ),
     *     @OA\Parameter(
     *         name="category_id",
     *         in="path",
     *         required=true,
     *         description="Identifier for category",
     *         @OA\Schema(
     *             type="Int",
     *             example="321"
     *         )
     *     ),
     *     @OA\Parameter(
     *         name="name",
     *         in="path",
     *         required=false,
     *         description="Set name of the category",
     *         @OA\Schema(
     *             type="String",
     *             example="Schoggi"
     *         )
     *     ),
     *     requestBody=@OA\RequestBody(
     *         request="/API/Update/Category/{parameter}",
     *         required=false,
     *         description="Nothing",
     *     ),
     *     @OA\Response(response="201", description="Category update"))
     *     v@OA\Response(response="401", description="Unauthorized (need Authentication: /API/Authenticate)"))
     *     v@OA\Response(response="418", description="Missing parameter (need category_id: /API/Update/Category)"))
     *     v@OA\Response(response="500", description="Server Error (Query statement error)"))
     * )
  */
  $app->put("/API/Update/Category/{parameter}", function (Request $request, Response $response, $args) {
  
    // check if user is authenticated
    if (isset($_COOKIE["token"]) && Token::validate($_COOKIE["token"], "sec!ReT423*&")) {
  
      // get params from link
      $params       = $args["parameter"];
  
      // split params by &
      $pieces = explode("&", $params);
  
      $categorys   = [];
      $sql = [];
      $categoryId = 0;
      $isCategoryId = false;
  
      // structure parameters from request
      foreach($pieces as $key => $value) {
        
        // split by =
        $piece = explode("=", $value);
  
        // check if value from column is set
        if (isset($piece[1])) {
  
          // check if column not category_id
          if ($piece[0] !== "category_id") {
  
            // set column into a array
            $sql[] = " $piece[0] = ?";
  
            // set values into array
            array_push($categorys, $piece[1]);
          } else {
  
            // if column category_id have value get value from it and set boolean to true
            if (isset($piece[1])) {
              $isCategoryId = true;
              $categoryId = $piece[1];
            }
          }
        }
      }
  
      if ($isCategoryId === false) {
  
        // send error message
        $response->getBody()->write("category_id is required");
  
        // send i'm a Teapot for fun ;)
        http_response_code(418); 
        return $response;
      }
  
      // set table product
      $tableProduct = new Table();
      $tableProduct->tableName = "category";
  
      // insert product into database
      $result = $tableProduct->updateCategory($categorys, $sql, $categoryId);
  
      http_response_code(201);
    } else {
  
      // error message for unauthorized user
      $response->getBody()->write("token not valid");
      http_response_code(401); 
    }
  
    // send successful message
    $response->getBody()->write("Category successful updated");
    return $response;
  });

  /**
     * @OA\Delete(
     *     path="/API/Delete/Category/{parameter}",
     *     summary="Delete a specific category",
     *     tags={"Delete Category"},
     *     @OA\Parameter(
     *         name="category_id",
     *         in="path",
     *         required=true,
     *         description="Primary key from category",
     *         @OA\Schema(
     *             type="Integer",
     *             example="41"
     *         )
     *     ),
     *     @OA\Response(response="200", description="Successful Category deleted"))
     *     v@OA\Response(response="401", description="Unauthorized (need Authentication: /API/Authenticate)"))
     *     v@OA\Response(response="500", description="Server Error (Query statement error)"))
     * )
  */
  $app->delete("/API/Delete/Category/{parameter}", function (Request $request, Response $response, $args) { 

    // check if user is authenticated
    if (isset($_COOKIE["token"]) && Token::validate($_COOKIE["token"], "sec!ReT423*&")) {

      // get param from link
      $categoryId       = $args["parameter"];

      // set table product
      $tableProduct = new Table();
      $tableProduct->tableName = "category";

      // insert product into database
      $result = $tableProduct->deleteCategory($categoryId);
      http_response_code(201);
    } else {

      // error message for unauthorized user
      $response->getBody()->write("token not valid");
      http_response_code(401); 
    }

    // send successful message
    $response->getBody()->write("Category successful deleted");
    return $response; 
  });

  /**
     * @OA\Get(
     *     path="/API/Get/All/Category",
     *     summary="Get all Categorys from Database",
     *     tags={"Get Categorys"},
     *     @OA\Response(response="200", description="Successful Category selected"))
     *     v@OA\Response(response="401", description="Unauthorized (need Authentication: /API/Authenticate)"))
     *     v@OA\Response(response="500", description="Server Error (Query statement error)"))
  */
  $app->get("/API/Get/All/Category", function (Request $request, Response $response, $args) {

    // check if user is authenticated
    if (isset($_COOKIE["token"]) && Token::validate($_COOKIE["token"], "sec!ReT423*&")) {
  
      // set table product
      $tableProduct = new Table();
      $tableProduct->tableName = "category";
  
      // select specific product by product_id
      $result = $tableProduct->selectAll();
  
      // iterate over result and set output accordingly into response body
      while ($row = $result->fetch(PDO::FETCH_ASSOC))
      {
        $response->getBody()->write("active: " . $row["active"] . " name: " . $row["name"] . " ");
        http_response_code(200); 
      }
    } else {

      // error message for unauthorized user
      $response->getBody()->write("token not valid");
      http_response_code(401); 
    }
    
    return $response;
  });

  // let app run
  $app->run();
?>