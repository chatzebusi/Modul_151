<?php

  // create database connection
  try {
    $database = new PDO("mysql:host=localhost;dbname=apishop", "root", "");
  } catch (Exception $exception) {
    http_response_code(500);
    echo "[ERROR]: Cannot connect to Database" . $exception->getMessage();
    die();
  };

  class Table {
    public $tableName;

    // insert statement for insert new Product into product table
    public function insertIntoProduct($value, $isCategorySet) {
      global $database;
      $database->beginTransaction();
      try {

        // get actual time and calculate actual time + 1 month to set valid_to
        $date = date('Y-m-d', strtotime(date('Y-m-d'). ' +1 months'));

        // if category set insert category foreign key
        if ($isCategorySet === true) {
          $statement = $database->prepare("INSERT INTO " . $this->tableName . "(sku, active, id_category, name, image, description, price, stock, valid_to) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ? );");

          // bind params
          $statement->bindParam(1, $value[0], PDO::PARAM_STR);
          $statement->bindParam(2, $value[1], PDO::PARAM_BOOL);
          $statement->bindParam(3, $value[2], PDO::PARAM_INT);
          $statement->bindParam(4, $value[3], PDO::PARAM_STR);
          $statement->bindParam(5, $value[4], PDO::PARAM_STR);
          $statement->bindParam(6, $value[5], PDO::PARAM_STR);
          $statement->bindParam(7, $value[6], PDO::PARAM_INT);
          $statement->bindParam(8, $value[7], PDO::PARAM_INT);
          $statement->bindParam(9, $date, PDO::PARAM_STR);
        } else {
          $statement = $database->prepare("INSERT INTO " . $this->tableName . "(sku, active, name, image, description, price, stock, valid_to) VALUES(?, ?, ?, ?, ?, ?, ?, ? );");

          // bind params
          $statement->bindParam(1, $value[0], PDO::PARAM_STR);
          $statement->bindParam(2, $value[1], PDO::PARAM_BOOL);
          $statement->bindParam(3, $value[2], PDO::PARAM_STR);
          $statement->bindParam(4, $value[3], PDO::PARAM_STR);
          $statement->bindParam(5, $value[4], PDO::PARAM_STR);
          $statement->bindParam(6, $value[5], PDO::PARAM_INT);
          $statement->bindParam(7, $value[6], PDO::PARAM_INT);
          $statement->bindParam(8, $date, PDO::PARAM_STR);
        }
    
        $statement->execute();
    
        $database->commit();
  
      } catch(Exception $exception) {
        $database->rollBack();
        http_response_code(500);
        die();
      }
    }

    // insert statement for insert new Category into category table
    public function insertIntoCategory($value) {
      global $database;
      $database->beginTransaction();
      try {

        // get actual time and calculate actual time + 1 month to set valid_to
        $date = date('Y-m-d', strtotime(date('Y-m-d'). ' +1 months'));
        $statement = $database->prepare("INSERT INTO " . $this->tableName . "(active, name, valid_to) VALUES(?, ?, ? );");

        // bind params
        $statement->bindParam(1, $value[0], PDO::PARAM_BOOL);
        $statement->bindParam(2, $value[1], PDO::PARAM_STR);
        $statement->bindParam(3, $date, PDO::PARAM_STR);
    
        $statement->execute();
    
        $database->commit();
  
      } catch(Exception $exception) {
        $database->rollBack();
        http_response_code(500);
        die();
      }
    }
  
    // updated statement to update one specific product with product_id
    public function updateProduct($products, $sql, $productId) {
    global $database;
      $database->beginTransaction();
      try { 

        // update products dynamic on each given param
        $statement = $database->prepare("UPDATE " . $this->tableName . " SET" .  implode(' ,', $sql) . " WHERE product_id = ?;");
  
        // iterate over products and bind them 
        $counter = 0;
        for ($i = 0; $i < count($products); $i++) {
          $counter++;
          $statement->bindParam($counter, $products[$i]);
        }
  
        // bind productId always as last
        $counter++;
        $statement->bindParam($counter, $productId);
  
        
        $statement->execute();
        
        $database->commit();
  
      } catch(Exception $exception) {
        $database->rollBack();
        http_response_code(500);
        die();
      }
    }

    // update statement to update one specific Category with category_id
    public function updateCategory($categories, $sql, $categoryId) {
    global $database;
      $database->beginTransaction();
      try { 

        // update categories dynamic on each given param
        $statement = $database->prepare("UPDATE " . $this->tableName . " SET" .  implode(' ,', $sql) . " WHERE category_id = ?;");
  

        // iterate over products and bind them 
        $counter = 0;
        for ($i = 0; $i < count($categories); $i++) {
          $counter++;
          $statement->bindParam($counter, $categories[$i]);
        }
  
        // bind categoryId always as last
        $counter++;
        $statement->bindParam($counter, $categoryId);
  
        
        $statement->execute();
        
        $database->commit();
  
      } catch(Exception $exception) {
        $database->rollBack();
        http_response_code(500);
        die();
      }
    }

    // select statement to get all values from table with $tablename_id
    public function select($id = null) {
      // get global set variable
      global $database;
      return $database->query("SELECT * FROM " . $this->tableName . " WHERE " . $this->tableName ."_id = " . $id);
    }
  
    // select statement to select all values from specific table
    public function selectAll($id = null) {
      // get global set variable
      global $database;
      return $database->query("SELECT * FROM " . $this->tableName . ";");
    }

    // update statement to set valid_to to actual date to delete this Product
    public function deleteProduct($productId) {
      $time = date("Y-m-d H:i:s");

      // get global set variable
      global $database;
      $database->beginTransaction();
      try {
  
      $statement = $database->prepare("UPDATE " . $this->tableName . " SET valid_to = ? WHERE product_id = ?;");
  
      $statement->bindParam(1, $time, PDO::PARAM_STR);
      $statement->bindParam(2, $productId, PDO::PARAM_INT);
  
      $statement->execute();
        
      $database->commit();
  
      } catch(Exception $exception) {
        $database->rollBack();
        http_response_code(500);
        die();
      }
      
    }

    // update statement to set valid_to to actual date to delete this Category
    public function deleteCategory($categoryId) {
      $time = date("Y-m-d H:i:s");

      // get global set variable
      global $database;
      $database->beginTransaction();
      try {
  
      $statement = $database->prepare("UPDATE " . $this->tableName . " SET valid_to = ? WHERE category_id = ?;");
  
      $statement->bindParam(1, $time, PDO::PARAM_STR);
      $statement->bindParam(2, $categoryId, PDO::PARAM_INT);
  
      $statement->execute();
        
      $database->commit();
  
      } catch(Exception $exception) {
        $database->rollBack();
        http_response_code(500);
        die();
      }
    }
  };
?>